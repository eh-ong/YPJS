package ypjs.project.domain.enums;

public enum PayStatus {

    OK, READY, CANCEL
}