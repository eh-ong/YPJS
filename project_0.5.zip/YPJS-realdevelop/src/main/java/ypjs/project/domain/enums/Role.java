package ypjs.project.domain.enums;

public enum Role {
    ROLE_ADMIN, ROLE_CUSTOMER
}
