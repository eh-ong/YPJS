package ypjs.project.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import ypjs.project.domain.Category;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class CategoryControllerTest {


    //		Category category =  new Category();
//
//		System.out.println(category);
//
//		CategoryRequestDto categoryRequestDto = new CategoryRequestDto(category.getCategoryId(), "하위1");
//
//		CategoryController categoryController;
//
//		categoryController.saveCategory(categoryRequestDto);


//    @Test
//    @Rollback(value = false)
//    public void category() throws Exception {
//        Category category
//    }

}