package ypjs.project.domain.enums;

public enum Status {
    MEMBER, WITHDRAWAL
}
