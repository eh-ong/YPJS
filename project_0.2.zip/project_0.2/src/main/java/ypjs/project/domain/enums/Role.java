package ypjs.project.domain.enums;

public enum Role {
    ADMINISTER, CUSTOMER
}
