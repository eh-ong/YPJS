package ypjs.project.domain.enums;

public enum OrderStatus {  //주문상태
    결제대기중, 주문완료, 배송준비중, 배송중, 배송완료, 주문취소
}
