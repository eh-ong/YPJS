package ypjs.project.domain.enums;

public enum DeliveryStatus {  //배송상태
    배송준비중, 배송중, 배송완료
}
