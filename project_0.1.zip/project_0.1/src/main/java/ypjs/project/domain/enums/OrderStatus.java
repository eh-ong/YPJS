package ypjs.project.domain.enums;

public enum OrderStatus {  //주문상태
    주문완료, 배송중비중, 배송중, 배송완료, 주문취소
}
