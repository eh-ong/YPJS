package ypjs.project.domain.enums;

public enum DeliveryStatus {  //배송상태
    READY, SHIPPING, DELIVERED
}
