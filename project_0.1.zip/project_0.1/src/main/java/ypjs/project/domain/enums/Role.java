package ypjs.project.domain.enums;

public enum Role {
    administer, customer
}
