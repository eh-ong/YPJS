package ypjs.project.domain.enums;

public enum Status {
    member, withdrawal
}
