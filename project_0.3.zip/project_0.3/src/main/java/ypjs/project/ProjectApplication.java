package ypjs.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectApplication {

	public static void main(String[] args) {

		SpringApplication.run(ProjectApplication.class, args);
		System.out.println("hi");
		System.out.println("확인용");
		System.out.println("진짜확인용");

	}

}
