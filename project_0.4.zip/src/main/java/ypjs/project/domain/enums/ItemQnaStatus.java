package ypjs.project.domain.enums;

public enum ItemQnaStatus {  //상품문의
    PENDING, ANSWERED
}
