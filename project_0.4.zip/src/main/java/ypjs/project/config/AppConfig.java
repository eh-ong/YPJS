package ypjs.project.config;

import com.siot.IamportRestClient.IamportClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    String apiKey ="2642475561011032";
    String secretKey ="HYjznEfuDdPwFZJVEMFHmr0LLH9gazmEoJA8YsCT8GuSCO90VdxO19dhFdVSv6n52DK4mHGaSEwr6zJ5";

    @Bean
    public IamportClient iamportClient(){

        return new IamportClient(apiKey, secretKey);
    }

}